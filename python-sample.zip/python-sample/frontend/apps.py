from django.apps import AppConfig


class RentaladminConfig(AppConfig):
    name = 'backend'
