#Python Admin panel
##Getting Started


# Start App

```
python manage.py makemigrations
python manage.py migrate
python manage.py runserver
```